package com.jarvis.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final String HOME_URL = "http://localhost:8765/";
    private static final String BG = "#06121a";

    private WebView web;
    private SpeechRecognizer recognizer;
    private int session = 0;
    private String pendingLang = null;

    private static final String OFFLINE_HTML =
            "<!doctype html><html><head><meta charset='utf-8'>"
                    + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                    + "<style>body{margin:0;background:#06121a;color:#d7f5ef;font-family:sans-serif;"
                    + "display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center}"
                    + ".b{padding:24px;max-width:320px}h1{color:#2de2c4;letter-spacing:4px;font-size:22px}"
                    + "p{line-height:1.5;opacity:.85}button{background:#2de2c4;color:#06121a;border:0;"
                    + "border-radius:12px;padding:14px 22px;font-size:16px;margin:6px;font-weight:bold}"
                    + "</style></head><body><div class='b'><h1>JARVIS</h1>"
                    + "<p>Jarvis ka server chal nahi raha.<br>Termux kholo aur ye chalao:<br>"
                    + "<b>termux-wake-lock ; python ~/jarvis_server.py</b></p>"
                    + "<button onclick='JarvisNative.openTermux()'>Termux kholo</button>"
                    + "<button onclick='JarvisNative.retry()'>Dobara try</button>"
                    + "<p style='font-size:13px;opacity:.6'>Server chalte hi ye apne aap khul jayega.</p></div>"
                    + "<script>setInterval(function(){fetch('http://localhost:8765/ping',{mode:'no-cors'})"
                    + ".then(function(){JarvisNative.retry()}).catch(function(){})},3000);</script>"
                    + "</body></html>";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor(BG));
        getWindow().setNavigationBarColor(Color.parseColor(BG));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(BG));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);

        web.addJavascriptInterface(new Bridge(), "JarvisNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String h = u.getHost();
                if ("localhost".equals(h) || "127.0.0.1".equals(h)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL("http://localhost/offline", OFFLINE_HTML,
                            "text/html", "utf-8", null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    String h = request.getOrigin().getHost();
                    if ("localhost".equals(h) || "127.0.0.1".equals(h)) {
                        request.grant(request.getResources());
                    } else {
                        request.deny();
                    }
                });
            }
        });

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }

        web.loadUrl(HOME_URL);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (pendingLang != null) {
            String lang = pendingLang;
            pendingLang = null;
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                startListen(lang);
            } else {
                deliver(null, "not-allowed", session);
            }
        }
    }

    private void deliver(String text, String err, int id) {
        if (id != session) {
            return;
        }
        final String js = "window.__jvStt&&window.__jvStt("
                + (text == null ? "null" : JSONObject.quote(text)) + ","
                + (err == null ? "null" : JSONObject.quote(err)) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private void startListen(String lang) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        final int my = ++session;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            deliver(null, "service-not-allowed", my);
            return;
        }
        if (recognizer != null) {
            recognizer.destroy();
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
            }

            @Override
            public void onBeginningOfSpeech() {
            }

            @Override
            public void onRmsChanged(float rmsdB) {
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
            }

            @Override
            public void onError(int error) {
                String code;
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    code = "not-allowed";
                } else if (error == SpeechRecognizer.ERROR_NO_MATCH
                        || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    code = "no-speech";
                } else {
                    code = "network";
                }
                deliver(null, code, my);
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String t = (list != null && !list.isEmpty()) ? list.get(0) : "";
                deliver(t, null, my);
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(i);
    }

    private void stopListen() {
        session++;
        if (recognizer != null) {
            recognizer.cancel();
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(() -> startListen(lang));
        }

        @JavascriptInterface
        public void stopListen() {
            runOnUiThread(() -> MainActivity.this.stopListen());
        }

        @JavascriptInterface
        public void openTermux() {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.termux");
            if (i != null) {
                startActivity(i);
            }
        }

        @JavascriptInterface
        public void retry() {
            runOnUiThread(() -> web.loadUrl(HOME_URL));
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) {
            recognizer.destroy();
        }
        web.destroy();
        super.onDestroy();
    }
}
